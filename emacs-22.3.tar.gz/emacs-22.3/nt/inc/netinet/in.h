/* null version of <netinet/in.h> - <sys/socket.h> has everything */

/* arch-tag: 49ff589e-100e-4f8f-8b2a-1c3b542590df
   (do not change this comment) */
