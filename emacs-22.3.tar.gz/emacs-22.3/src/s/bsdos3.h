/* s/ file for BSDI BSD/OS 3.0 system.  */

#include "bsdos2.h"

#undef	LIBS_SYSTEM
#define LIBS_SYSTEM -lkvm

/* arch-tag: 726766f3-5a62-48bf-8e21-3b21ec6abe6f
   (do not change this comment) */
