/* Definitions file for GNU Emacs running on RISCiX 1.1 (bsd 4.3) */

#define  RISCiX_1_1	1
#define  RISCiX		11
#define  CRT0_O		/lib/crt0.o
#include "bsd4-3.h"

/* arch-tag: 382df034-9843-4a82-8a3a-2e50a4dd532c
   (do not change this comment) */
