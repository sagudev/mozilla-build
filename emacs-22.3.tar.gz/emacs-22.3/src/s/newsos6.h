/* Definitions file for GNU Emacs running on Sony's NEWS-OS 6.x  */

#include "usg5-4-2.h"

#define NEWSOS6
#define HAVE_TEXT_START

/* arch-tag: a0db9cb0-43bb-4f9e-85fa-384e30f02d74
   (do not change this comment) */
