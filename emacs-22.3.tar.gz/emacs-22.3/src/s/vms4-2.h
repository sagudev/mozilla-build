#include "vms.h"
#define VMS4_2

/* arch-tag: d9ff67bc-a899-44b2-a618-a73c821bb559
   (do not change this comment) */
